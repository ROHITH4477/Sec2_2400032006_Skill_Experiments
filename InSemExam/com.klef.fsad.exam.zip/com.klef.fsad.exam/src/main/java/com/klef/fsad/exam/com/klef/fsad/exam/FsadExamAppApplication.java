package com.klef.fsad.exam.com.klef.fsad.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsadExamAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsadExamAppApplication.class, args);
	}

}
